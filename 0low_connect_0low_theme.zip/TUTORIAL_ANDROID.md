# 📱 0LOW CONNECT — TUTORIAL SEM ERRO

## O que você recebeu
- `server.js` = servidor do chat/call
- `public/index.html` = interface
- `public/style.css` = visual
- `public/app.js` = funções
- `public/background.png` = fundo 0LOW vermelho/ciano
- `package.json` = dependências
- `README.md` = informações do projeto

## PARTE 1 — Colocar no GitHub pelo celular

1. Abra o GitHub no Chrome e entre na sua conta.
2. Crie um repositório novo chamado `0low-connect`.
3. Abra o repositório.
4. Toque em **Add file → Upload files**.
5. Extraia este ZIP primeiro.
6. Envie TODOS estes itens para o repositório:
   - `package.json`
   - `server.js`
   - pasta `public`
   - `README.md`
7. Dentro de `public` precisam estar:
   - `index.html`
   - `style.css`
   - `app.js`
   - `background.png`
8. Faça o commit.

⚠️ NÃO envie somente o ZIP. O Render precisa enxergar `package.json` e `server.js` na raiz do repositório.

## PARTE 2 — Colocar online

1. Abra o Render e entre/crie sua conta.
2. Escolha **New → Web Service**.
3. Conecte o GitHub.
4. Selecione `0low-connect`.
5. Preencha:
   - Language: `Node`
   - Build Command: `npm install`
   - Start Command: `npm start`
6. Se aparecer escolha de plano, selecione o plano que você pretende usar.
7. Crie o Web Service.
8. Espere o deploy terminar.
9. Abra a URL `onrender.com` que aparecer.

## PARTE 3 — Testar

1. Abra o site.
2. Toque em `＋`.
3. Crie um servidor.
4. O código aparece no topo.
5. Toque no botão de convite/código e mande o código para seu amigo.
6. Seu amigo abre a MESMA URL.
7. Ele toca em entrar e coloca o código.
8. Agora vocês ficam no mesmo servidor.
9. Entre em **Call geral**.
10. Permita câmera e microfone.
11. Para passar a tela, toque no botão 📱 e confirme o compartilhamento do Android.

## Se a call não funcionar

- Os dois devem abrir o site por `https://`.
- Permita câmera e microfone no navegador.
- No Android, permita as permissões quando aparecerem.
- Para compartilhar tela, aceite a confirmação do sistema Android.
- Se um estiver no Wi‑Fi e outro na rede móvel, a conexão WebRTC pode depender da rede; esta versão usa STUN básico.

## Se o Render mostrar erro

Confira primeiro:
- `package.json` está na raiz.
- `server.js` está na raiz.
- pasta `public` está na raiz.
- `public/background.png` existe.
- Build = `npm install`
- Start = `npm start`

Não coloque `public` como Root Directory.

## Importante
Esta é uma versão funcional inicial. Servidores são mantidos em memória: se o processo reiniciar, os servidores/códigos podem desaparecer. Para virar um Discord completo, depois podemos adicionar contas, banco de dados, permissões, cargos, Nitro, upload de arquivos, histórico permanente e um servidor TURN para melhorar chamadas.

### Links oficiais
GitHub: https://github.com/
Render: https://render.com/
